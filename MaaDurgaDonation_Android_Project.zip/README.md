# Maa Durga Donation — Android Project

यह Android Studio project है। इसे Android Studio में खोलकर Gradle sync करें और Run से फोन/emulator पर test करें।
APK बनाने के लिए Android Studio में **Build > Build APK(s)** चुनें।

Current version: donor name, mobile, donation amount, local storage, search, total collection.
Production version में cloud database, authentication, receipts, reports और backup जोड़े जाने हैं।
