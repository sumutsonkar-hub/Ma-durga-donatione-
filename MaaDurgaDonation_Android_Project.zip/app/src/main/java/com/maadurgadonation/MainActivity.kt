package com.maadurgadonation

import android.app.Activity
import android.os.Bundle
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("donations", MODE_PRIVATE) }
    private lateinit var name: EditText; private lateinit var phone: EditText
    private lateinit var amount: EditText; private lateinit var search: EditText
    private lateinit var summary: TextView; private lateinit var results: TextView
    private fun load(): JSONArray = try { JSONArray(prefs.getString("data","[]")) } catch(_:Exception){JSONArray()}
    override fun onCreate(b: Bundle?) { super.onCreate(b); setContentView(R.layout.activity_main)
        name=findViewById(R.id.name); phone=findViewById(R.id.phone); amount=findViewById(R.id.amount)
        search=findViewById(R.id.search); summary=findViewById(R.id.summary); results=findViewById(R.id.results)
        findViewById<Button>(R.id.save).setOnClickListener { save() }
        search.setOnEditorActionListener { _,_,_-> render(); true }; render()
    }
    private fun save(){ val n=name.text.toString().trim(); val p=phone.text.toString().trim(); val a=amount.text.toString().toDoubleOrNull()
        if(n.isEmpty()||a==null||a<=0){Toast.makeText(this,"नाम और सही amount भरें",Toast.LENGTH_SHORT).show();return}
        val arr=load(); arr.put(JSONObject().put("name",n).put("phone",p).put("amount",a))
        prefs.edit().putString("data",arr.toString()).apply(); name.text.clear(); phone.text.clear(); amount.text.clear()
        Toast.makeText(this,"Donation save हो गया",Toast.LENGTH_SHORT).show(); render()
    }
    private fun render(){ val arr=load(); var total=0.0; val q=search.text.toString().trim().lowercase(); val sb=StringBuilder()
        for(i in 0 until arr.length()){ val o=arr.getJSONObject(i); val n=o.optString("name"); val p=o.optString("phone"); val a=o.optDouble("amount")
            total+=a; if(q.isEmpty()||n.lowercase().contains(q)||p.contains(q)) sb.append("👤 ").append(n).append("  ₹").append(a).append("\n📱 ").append(p).append("\n\n") }
        summary.text="Total Collection: ₹$total\nTotal Donors: ${arr.length()}"; results.text=if(sb.isEmpty())"Donor नहीं मिला" else sb.toString()
    }
}