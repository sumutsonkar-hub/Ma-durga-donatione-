plugins { id("com.android.application") }
android { namespace="com.maadurgadonation"; compileSdk=35
    defaultConfig { applicationId="com.maadurgadonation"; minSdk=24; targetSdk=35; versionCode=1; versionName="1.0" }
}
